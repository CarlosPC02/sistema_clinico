<div class="panel-heading">
    <center>PERSONAS ENCONTRADAS</center>
    <h6>CODIGO QUE VIENE DE BUSCARPERSONAS EN CONTROLADOR GENERICO: <?php echo e($codigo); ?> <small>SE ENVIA A SELECCIONAR EN CONTROLADOR GENERICO</small></h6>
</div>

<!-- Formulario de Listado de Persona -->
<?php echo e(csrf_field()); ?>

<div class="table-responsive">
    <div class="container-fluid">
        <table class="table table-bordered table-condensed">
            <thead>
                <th>ID</th>
                <th>Nombre</th>
                <th>Paterno</th>
                <th>Materno</th>
                <th>Fecha de Nacimiento</th>
                <th>Documento</th>
            </thead>
            <tbody>
                <?php foreach($personas as $persona): ?>
                <tr>
                    <td><?php echo e($persona-> id_persona); ?></td>
                    <td><?php echo e($persona-> nombre); ?></td>
                    <td><?php echo e($persona-> ap_paterno); ?></td>
                    <td><?php echo e($persona-> ap_materno); ?></td>
                    <td><?php echo e($persona-> fecha_nacimiento); ?></td>
                    <td><?php echo e($persona-> documento_identidad); ?></td>
                    <td><a href="<?php echo e(url('/SeleccionarPersona', [$persona->id_persona,$codigo])); ?>"> [Seleccionar] </a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>