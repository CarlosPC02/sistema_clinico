<?php $__env->startSection('content'); ?>
	
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>

	<div class="container">
		<h4>NUEVO BUSCAR/LISTAR PERSONAS</h4>

	<h6>CODIGO RECIBIDO DE PERSONA-CONTROLADOR: <?php echo e($codigo); ?> <small>SE ENVIA A CONTROLADOR GENERICO</small></h6>

	<div class="panel panel-default">
		<div class="panel-heading">
			<h4>Buscar</h4>
			<p class="navbar-text navbar-right" style="margin-top: -35px;"><button class="btn btn-info navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" onclick="document.location.href='<?php echo e(route('persona.create')); ?>'">Registrar Nueva</button></p>			
		</div>

		<div class="panel-body">

			<?php echo Form::open(); ?>	
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">

				<input type="hidden" name="codigo" value="<?php echo e($codigo); ?>" id="codigo">

				<div class="form-group col-md-3">
					<?php /* <?php echo Form::label('Nombre'); ?> */ ?>
					<?php /* onkeydown="convertiramayusculas()" onkeyup="convertiramayusculas()" */ ?>
					<?php echo Form::text('nombre',null,['id'=>'nombre','class'=>'form-control','placeholder'=>'Nombre','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

				</div>

				<div class="form-group col-md-3">
					<?php /* <?php echo Form::label('Apellido P'); ?> */ ?>
					<?php echo Form::text('apellido_paterno',null,['id'=>'apellido_paterno','class'=>'form-control','placeholder'=>'Apellido P','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

				</div>				

				<div class="form-group col-md-3">
					<?php /* <?php echo Form::label('Apellido M'); ?> */ ?>
					<?php echo Form::text('apellido_materno',null,['id'=>'apellido_materno','class'=>'form-control','placeholder'=>'Apellido M','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

				</div>

				<div class="form-group col-md-3">
	                <div class="col-sm-offset-3 col-sm-6">
	                    <button id="botonBuscarPersonas" type="button" class="btn btn-success"> Buscar </button>
	                </div>
	            </div>

			<?php echo Form::close(); ?>


			<?php echo e(csrf_field()); ?>


            <div class="container" id="resultadobusqueda">
            	<!--RESULTADO DE LA BUSQUEDA lstpersonsa.blade.php --> 
        	</div>
			
			

		</div>

		<?php /* <script type="text/javascript" src="<?php echo e(asset('js/BusquedaPersona.js')); ?>"></script> */ ?>

	</div>
	</div>

	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>