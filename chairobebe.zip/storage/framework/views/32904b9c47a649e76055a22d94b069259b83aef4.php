<?php $__env->startSection('content'); ?>

<!-- Titulo de Menu -->
    <div class="container-fluid titulo_general">
      <h6 id="titulo_principal">Calendario</h6>
    </div>
    <!-- Fin de Titulo -->

<div class="container-fluid marco_trabajo">
	<br><br><br>
	<h4 style="text-align:center;">Listado de Fechas de Calendario</h4>
	<br><br><br>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>