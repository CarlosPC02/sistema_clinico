<?php $__env->startSection('title','MENU DE TRABAJO'); ?>
<?php $__env->startSection('content'); ?>

<!-- Titulo de Menu -->
<div class="container-fluid titulo_general">
   <h6 id="titulo_principal">Menu de Trabajo</h6>
</div>

<div class="container-fluid marco_trabajo">

    <div><?php echo $__env->make('Persona.LstDatosBasicos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
    <?php if($resultado === 0): ?>
        <div class="alert alert-warning alerta_small">
            <p><small><span class="fui-question-circle"></span> Datos importantes incompletos. <a href="<?php echo e(route('paciente.edit',session('id_persona'))); ?>" style="color: #FFBF00;">Completar...</a></small></p>
            <!-- <p class="navbar-text navbar-right" style="margin-top: -35px;"><button class="btn btn-warning navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" onclick="document.location.href='<?php echo e(route('paciente.edit',session('id_persona'))); ?>'">Completar Ahora</button></p> -->
        </div>
    <?php else: ?>
        <div class="alert alert-success alerta_small">
            <p><small><span class="fui-check-circle"></span> Datos completos</small></p>
        </div>
    <?php endif; ?>

    <!-- Boton Signos Vitales -->
    <div class="cuadro_menu_paciente"> <a href=<?php echo e(route('medicion.show',session('id_persona'))); ?>>
        <div class="imagen_menu"> <img class="img-responsive" src="<?php echo e(asset ('../imagenes/menu/gabinete_w.png')); ?>" alt="Signos Vitales"></div>
        <h3 class="titulo_menu">Signos Vitales</h3>
        <div class="texto_menu"><p><small>Mediciones importantes del Paciente</small></p></div>
        </a>
    </div>

    <!-- Boton Historia Clinica -->
    <div class="cuadro_menu_paciente"> <a href="<?php echo e(route('historia.show',session('id_paciente'))); ?>">
        <div class="imagen_menu"> <img class="img-responsive" src="<?php echo e(asset ('../imagenes/menu/expediente_w.png')); ?>" alt="Historia"></div>
        <h3 class="titulo_menu">Historia Clinica</h3>
        <div class="texto_menu"><p><small>Antecedentes del Paciente</small></p></div>
        </a>
    </div>

    <!-- Boton Consulta -->
    <div class="cuadro_menu_paciente"> <a href="<?php echo e(route('consulta.show',session('id_paciente'))); ?>">
        <div class="imagen_menu"> <img class="img-responsive" src="<?php echo e(asset ('../imagenes/menu/estetoscopio_w.png')); ?>" alt="Consulta"></div>
        <h3 class="titulo_menu">Consulta</h3>
        <div class="texto_menu"><p><small>Administracion de Consultas</small></p></div>
        </a>
    </div>

    <!-- Boton Laboratorio -->
    <div class="cuadro_menu_paciente"> <a href="<?php echo e(route('ordenesL.show',session('id_paciente'))); ?>">
        <div class="imagen_menu"> <img class="img-responsive" src="<?php echo e(asset ('../imagenes/menu/microscopio_w.png')); ?>" alt="Laboratorio"></div>
        <h3 class="titulo_menu">Laboratorio</h3>
        <div class="texto_menu"><p><small>Resultados de Laboratorios</small></p></div>
        </a>
    </div>
    
    <!-- Boton Gabinete -->
    <div class="cuadro_menu_paciente"> <a href="<?php echo e(route('ordenesG.show',session('id_paciente'))); ?>">
        <div class="imagen_menu"> <img class="img-responsive" src="<?php echo e(asset ('../imagenes/menu/enfermera_w.png')); ?>" alt="Gabinete"></div>
        <h3 class="titulo_menu">Gabinete</h3>
        <div class="texto_menu"><p><small>Administracion de Imagenología</small></p></div>
        </a>
    </div>
    
    <!-- Boton Quirofano -->
    <div class="cuadro_menu_paciente"> <a href="#">
        <div class="imagen_menu"> <img class="img-responsive" src="<?php echo e(asset ('../imagenes/menu/quirofano_w.png')); ?>" alt="Quirofano"></div>
        <h3 class="titulo_menu">Quirofano</h3>
        <div class="texto_menu"><p><small>Programacion de Quirofano</small></p></div>
        </a>
    </div>
    
    <div class="cuadro_menu_paciente"> <a href="#">
        <div class="imagen_menu"> <img class="img-responsive" src="<?php echo e(asset ('../imagenes/menu/estadisticas_w.png')); ?>" alt="Otros"></div>
        <h3 class="titulo_menu">Estadisticas</h3>
        <div class="texto_menu"><p><small>Estasdisticas referidas al paciente</small></p></div>
        </a>
    </div>
</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>