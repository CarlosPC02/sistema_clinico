<?php $__env->startSection('content'); ?>
	
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>

	<div class="container" style="padding-top: 70px;">
		<h4>Agenda de Citas</h4>

		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Buscar Cita</h4>
				<p class="navbar-text navbar-right" style="margin-top: -35px;"><button class="btn btn-info navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" onclick="document.location.href='<?php echo e(route('cita.create')); ?>'">Registrar Nueva</button></p>			
			</div>

			<div class="panel-body">

				<?php echo Form::open(); ?>	
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
					<div class="container-fluid">
						
						<div class="form-group col-md-4">
			                <label for="dtp_input2" class="control-label">Fecha</label>
			                <div class="input-group date form_date" data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
			                    <input class="form-control" size="16" type="text" value="" readonly>
			                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
								<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
			                </div>
							<input type="hidden" id="dtp_input2" value="" /><br/>
			            </div>

						<div class="form-group col-md-4">
			                <label for="dtp_input3" class="control-label">Hora</label>
			                <div class="input-group date form_time" data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
			                    <input class="form-control" size="16" type="text" value="" readonly>
			                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
								<span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
			                </div>
							<input type="hidden" id="dtp_input3" value="" /><br/>
			            </div>			

						<?php /* <div class="form-group col-md-3">
							<?php echo Form::text('medico',null,['id'=>'medico','class'=>'form-control','placeholder'=>'Apellido Medico']); ?>

						</div> */ ?>

						<label class="form-group col-md-4">Medico</label>
				        <div class="selectContainer col-md-4">
				            <select class="form-control" id="id_medico" name="id_medico">
				            	<option value="">Elija Medico</option>
				            	<?php foreach($medicos as $medico): ?>
			                        <option value="<?php echo e($medico->id_medico); ?>"><?php echo e($medico->nombre." ". $medico->apellido_paterno." ".$medico->apellido_materno); ?></option>
			                     <?php endforeach; ?>
				            </select>
				        </div>

						<div class="form-group col-md-3">
			                    <button id="botonBuscarCitas" type="button" class="btn btn-success btn-block"> Buscar </button>
			            </div>

					</div>				

				<?php echo Form::close(); ?>


				<?php echo e(csrf_field()); ?>


	            <div class="container" id="resultadoBusquedaCita">
	            	<div class="panel-heading">
					    <center>CITAS PARA : <?php echo e($fecha); ?></center>
					</div>

	            	<div class="table-responsive">
					    <div class="container-fluid">
					        <table class="table table-bordered table-condensed">
					            <thead>
					                    <th>Institucion</th>
					                    <th>Fecha</th>
					                    <th>Hora</th>
					                    <th>Nombre</th>
					                    <th>Paterno</th>
					                    <th>Motivo</th>
					                    <th>Medico</th>
					                </thead>
					            <tbody>
					                    <?php foreach($citas as $cita): ?>
					                    <tr>
					                        <td><?php echo e($cita-> codigo_institucion); ?></td>
					                        <td><?php echo e($cita-> fecha); ?></td>
					                        <td><?php echo e($cita-> hora); ?></td>
					                        <td><?php echo e($cita-> nombre); ?></td>
					                        <td><?php echo e($cita-> ap_paterno); ?></td>
					                        <td><?php echo e($cita-> motivo); ?></td>
					                        <td> <?php echo e($cita->nombrem); ?> <?php echo e($cita->apellidom); ?></td>

					                    </tr>
					                    <?php endforeach; ?>
					                </tbody>
					        </table>
					    </div>
					</div>
	        	</div>
				
				

			</div>

			<?php /* <script type="text/javascript" src="<?php echo e(asset('js/BusquedaPersona.js')); ?>"></script> */ ?>

		</div>
	</div>

	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>