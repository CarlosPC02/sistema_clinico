<div class="alert alert-warning">
	
	<h6>ATENCION!</h6>
	<p>Hay datos importantes que aun no se han detallado</p>
	<p class="navbar-text navbar-right" style="margin-top: -35px;"><button class="btn btn-warning navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" onclick="document.location.href='<?php echo e(route('paciente.edit'), session('id_persona')); ?>'">Completar Ahora</button></p>
</div>