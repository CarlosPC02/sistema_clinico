<?php $__env->startSection('content'); ?>

    <div class="container" style="padding-top: 70px;">
        <div class="panel panel-default">
        <div class="panel-heading">
            <h6>Datos Persona</h6>
            <p class="navbar-text navbar-right" style="margin-top: -35px;"><button class="btn btn-info navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" onclick="document.location.href='<?php echo e(url('/persona/show')); ?>'">Volver</button></p>
        </div>
        
        <div class="panel-body">
            <?php foreach($persona as $persona): ?>
            <center><?php echo e($persona->nombre." ".$persona->ap_paterno." ".$persona->ap_materno); ?></center>
                <?php echo e(csrf_field()); ?>

                                    
                    <label for="documento_identidad" class="col-sm-3 control-label">Documento Identidad</label>
                    <div class="col-sm-6">
                         <?php echo e($persona->documento_identidad); ?>

                    </div>
                                
                    <label for="tipo_documento" class="col-sm-3 control-label">Tipo Documento</label>
                    <div class="col-sm-6">
                        <?php echo e($persona->tipo_documento); ?>

                    </div>
                
                    
                    <label for="telefono" class="col-sm-3 control-label">Telefono</label>
                    <div class="col-sm-6">
                        <?php echo e($persona->no_telefono); ?>

                    </div>
                
                    
                    <label for="celular" class="col-sm-3 control-label">Celular</label>
                    <div class="col-sm-6">
                        <?php echo e($persona->no_celular); ?>

                    </div>
                
                    
                    <label for="email" class="col-sm-3 control-label">email</label>
                    <div class="col-sm-6">
                        <?php echo e($persona->email); ?>

                    </div>
                
                    
                    <label for="direccion" class="col-sm-3 control-label">Direccion</label>
                    <div class="col-sm-6">
                        <?php echo e($persona->direccion); ?>

                    </div>
                
                    <?php foreach($imagenpersona as $imagenpersona): ?>
                    <label for="imagen" class="col-sm-3 control-label">Imagen</label>
                    <div class="col-sm-6">
                        <img src="<?php echo e(print($imagenpersona->imagen)); ?>" alt="foto">
                    </div>
                    <?php endforeach; ?>
            <?php endforeach; ?> 
        </div>

    </div>
    </div>
    
   
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>