<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
<head>
	<!--bootstrap-->
	<title>Registro de Pacientes</title>
	<script>
		function alcargar(){
							$('#foto').hover(function(){
														$(this).find('a').fadeIn();
														},
											function(){
														$(this).find('a').fadeOut();
														}
											);
							$('#eligeArchivo').on('click',function(e){
																		e.preventDefault();
																		$('#imagenpersona').click();
																	}
												);

							$('input[type=file]').change(function(){
								var nombre=(this.files[0].name).toString();
								var reader=new FileReader();

								$('#infoArchivo').text('');
								$('#infoArchivo').text(nombre);

								reader.onload=function(e){
									$('#foto img').attr('src',e.target.result);
								}

								reader.readAsDataURL(this.files[0]);
							});
							}
	</script>
</head>

<body onload="alcargar();">
	<div class="container">
	      <h6 id="titulo_principal">Registro de Paciente</h6>
	</div>

	<?php if($errors->any()): ?>
		<div class="container marco_trabajo">
			<div class="alert alert-danger">
		      <button type="button" class="close" data-dismiss="alert">&times;</button>
		      <strong>Por favor corrige los siguentes errores:</strong>
		      <ul>
		      <?php foreach($errors->all() as $error): ?>
		        <li><?php echo e($error); ?></li>
		      <?php endforeach; ?>
		      </ul>
    		</div>
		</div>
    
 	<?php endif; ?>

	<div class="container">	
		<div role="tabpanel">
			<!--crea boton de menu al estrecharse la resolucion de pantalla-->
			<div class="navbar-header navbar-inverse">
			    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			    </button>
			</div>
			
			<!--incluye el menu en la referencia del boton creado antes-->
			<div class="collapse navbar-collapse" id="menu" role="navigation">
				<ul class="nav nav-tabs" role="tablist">
					<li class="active" role="presentation"><a href="#tab1" aria-controls="" data-toggle="tab" role="tab">Informacion basica</a></li>
					<li role="presentation"><a href="#tab2" aria-controls="" data-toggle="tab" role="tab">Informacion de contacto</a></li>
					<li role="presentation"><a href="#tab3" aria-controls="" data-toggle="tab" role="tab">Informacion de pago</a></li>
					<li role="presentation"><a href="#tab4" aria-controls="" data-toggle="tab" role="tab">Informacion adicional</a></li>
				</ul>
			</div>
			
			<?php echo Form::open(['route'=>'persona.store','method'=>'POST','class'=>'form-horizontal']); ?>

			
			<?php echo e(csrf_field()); ?>


			<div class="tab-content">
				
					<!-- seccion informacion basica -->
					<div role="tabpanel" class="tab-pane active" id="tab1">
						<div class="container">
							<div class="row">						
								<!-- formulario de datos basicos -->
								<div class="col-xs-12 col-sm-8 col-md-8">
		                       
										<div class="form-group">
											<?php echo Form::label('Nombre:'); ?>

											<?php echo Form::text('nombre',null,['id'=>'nombre','class'=>'form-control','placeholder'=>'Nombre','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
											<?php echo Form::label('A. Paterno:'); ?>

											<?php echo Form::text('ap_paterno',null,['id'=>'ap_paterno','class'=>'form-control','placeholder'=>'Apellido Paterno','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
											<?php echo Form::label('A. Materno:'); ?>

											<?php echo Form::text('ap_materno',null,['id'=>'ap_materno','class'=>'form-control','placeholder'=>'Apellido Materno','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
							                <label for="fecha_nacimiento" class="control-label">Fecha de Nacimiento</label>
							                <div class="input-group date form_date" data-date="" data-date-format="dd MM yyyy" data-link-field="fecha_nacimiento" data-link-format="yyyy-mm-dd">
							                    	<input class="form-control" size="16" type="text" value="" readonly />
							                    	<span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
														<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
							                </div>
											<input type="hidden" id="fecha_nacimiento" name="fecha_nacimiento" value="" /><br/>
						            	</div>

										<div class="form-group">
									        <label class="control-label">Tipo Documento</label>
									        <div class="selectContainer">
									            <select name="tipo_documento" id="tipo_documento" class="form-control">
			                  						<?php foreach($dominios as $dominio): ?>
			                    							<option value="<?php echo e($dominio->codigo_dominio); ?>"><?php echo e($dominio->descripcion); ?></option>
			                  						<?php endforeach; ?>  
		                						</select>
									        </div>
									   	</div>

										<div class="form-group">
											<?php echo Form::label('Documento de Identidad :'); ?>

											<?php echo Form::text('documento_identidad',null,['id'=>'documento_identidad','class'=>'form-control','placeholder'=>'Documento de Identidad','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
											<?php echo Form::label('Genero:'); ?>

											<?php echo Form::radio('genero','M',['id'=>'genero']); ?> <br>
											<?php echo Form::radio('genero','F',['id'=>'genero']); ?>

											<?php /* <div>
													<input type="radio" name="genero" id="genero" value="M" />Masculino
											</div>	
											<div>
													<input type="radio" name="genero" id="genero2" value="F" />Femenino
											</div> */ ?>
										</div>

										<div class="form-group">
							                <div class="col-sm-offset-3 col-sm-6">
							                    <button type="submit" class="btn btn-default">
							                        <i class="fa fa-plus"></i> Registrar
							                    </button>
							                </div>
							         	</div>
								</div>
							</div>						
						</div>
					</div>
					<!--seccion de informacion de contacto-->
					<div class="tab-pane" id="tab2" role="tabpanel">
						<div class="container">
							<div class="row">
								<div class="col-xs-12 col-sm-8 col-md-8">

										<div class="form-group">
											<?php echo Form::label('Celular :'); ?>

											<?php echo Form::number('no_celular',null,['id'=>'no_celular','class'=>'form-control','placeholder'=>'Telefono Celular','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
											<?php echo Form::label('Telefono de Domicilio:'); ?>

											<?php echo Form::number('no_telefono',null,['id'=>'no_telefono','class'=>'form-control','placeholder'=>'Telefono de Domicilio','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
											<?php echo Form::label('Telefono del Trabajo:'); ?>

											<?php echo Form::text('no_telefono_trabajo',null,['id'=>'no_telefono_trabajo','class'=>'form-control','placeholder'=>'Telefono del Trabajo','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
											<?php echo Form::label('e-Mail :'); ?>

											<?php echo Form::email('email',null,['id'=>'email','class'=>'form-control','placeholder'=>'e-Mail','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
											<?php echo Form::label('Direccion Actual :'); ?>

											<?php echo Form::text('direccion',null,['id'=>'direccion','class'=>'form-control','placeholder'=>'Direccion Actual','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
											<?php echo Form::label('Ciudad de Residencia:'); ?>

											<?php echo Form::text('ciudad_residencia',null,['id'=>'ciudad_residencia','class'=>'form-control','placeholder'=>'Ciudad de Residencia','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-group">
											<?php echo Form::hidden('estado','AC',['id'=>'estado','class'=>'form-control','placeholder'=>'Estado']); ?>

										</div>

								</div>
							</div>
						</div>
					</div>

					<!--seccion de informacion de pago-->
					<div class="tab-pane" id="tab3" role="tabpanel">
						<div class="container">
							<div class="row">
								<div class="col-xs-12 col-sm-4 col-md-4">
										
										<div class="form-group">
									        <label class="control-label">Tipo Seguro</label>
									        <div class="selectContainer">
									            <select class="form-control" id="tipo_seguro" name="tipo_seguro">
									            <?php foreach($tipos_seguros as $tipo_seguro): ?>
		                                            <option value="<?php echo e($tipo_seguro->codigo_dominio); ?>"><?php echo e($tipo_seguro->descripcion); ?></option>
		                                        <?php endforeach; ?>  
									            </select>
									        </div>
									   	</div>

										<div class="form-group" id='detalle_seguros' name='detalle_seguros'>
											<input type="hidden" name="_token1" value="<?php echo e(csrf_token()); ?>" id="token1">
									        <label class="control-label">Seguro vigente</label>
									        <div class="selectContainer" id="seguros" name="seguros">
									            <select class="form-control" id="codigo_seguro" name="codigo_seguro">
									                <option value="">Elija una opcion</option>
									            </select>
									        </div>
								    	</div>

								    	<div class="form-group">
											<?php echo Form::label('Numero de Autorizacion:'); ?>

											<?php echo Form::text('matricula_seguro',null,['id'=>'matricula_seguro','class'=>'form-control','placeholder'=>'Numero de Autorizacion','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

								</div>
							</div>
						</div>
					</div>

					<!--seccion de demograficos y notas-->
					<div class="tab-pane" id="tab4" role="tabpanel">
						<div class="container">
							<div class="row">
								<div class="col-xs-12 col-sm-4 col-md-4">

										<div class="form-group">
											<?php echo Form::label('Religion:'); ?>

											<?php echo Form::text('religion',null,['id'=>'religion','class'=>'form-control','placeholder'=>'Religion','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>

										<div class="form-horizontal">
											<div class="form-group">
												<label for="registro" class="control-label">Numero de Registro</label>
												<div class="bordes_izq_der">
													<input id="registro" type="text" class="form-control" placeholder="Numero de Registro" autocomplete="off">
												</div>
												<div class="bordes_izq_der">
													<button id="btnGenerar" type="button" class="btn btn-success">Generar</button>
												</div>
											</div>
										</div>
								</div>

								<div class="col-xs-12 col-sm-4 col-md-4">

										<div class="form-group">
											<?php echo Form::label('Observaciones:'); ?>

											<?php echo Form::text('observaciones',null,['id'=>'observaciones','class'=>'form-control','placeholder'=>'Observaciones','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

										</div>
								</div>

								<div class="col-xs-12 col-sm-4 col-md-4">
									<div class="thumbnail" id="foto">
										<a href="" class="btn btn-default" id="eligeArchivo">Elegir Foto</a>
										<img src="<?php echo e(asset('imagenes/iconos/silueta.png')); ?>" alt="">
									</div>
										<span class="alert alert-info" id="infoArchivo">No se ha elegido archivo</span>
										<input type="file" name="imagenpersona" id="imagenpersona">
								</div>
							</div>
						</div>
					</div>
		      	
			</div>

			<?php echo Form::close(); ?> 			  		

		</div>
	</div>

	<?php /* <script type="text/javascript" src="<?php echo e(asset('js/seguros.js')); ?>"></script> */ ?>
	
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>