<div class="panel-heading col-md-6" style="margin-left: -20px; margin-bottom: -10px; text-align: center;">
    <p style="text-align: left; float: left;"><strong>Coincidencias Encontradas</strong></p>
</div>

<!-- Formulario de Listado de Persona -->
<?php echo e(csrf_field()); ?>

<div class="table-responsive" style="margin-left: -20px; margin-right: 20px;">
    <div class="container-fluid">
        <table class="table table-bordered table-condensed tabla_small">
            <thead>
                <th>ID</th>
                <th>Nombre</th>
                <th>Paterno</th>
                <th>Materno</th>
                <th>Fecha de Nacimiento</th>
                <th>Documento</th>
                <th>Opciones</th>
            </thead>
            <tbody>
                <?php foreach($personas as $persona): ?>
                <tr>
                    <td><?php echo e($persona-> id_persona); ?></td>
                    <td><?php echo e($persona-> nombre); ?></td>
                    <td><?php echo e($persona-> ap_paterno); ?></td>
                    <td><?php echo e($persona-> ap_materno); ?></td>
                    <td><?php echo e($persona-> fecha_nacimiento); ?></td>
                    <td><?php echo e($persona-> documento_identidad); ?></td>
                    <td><a href="<?php echo e(url('/SeleccionarPersona', [$persona->id_persona,$codigo])); ?>"> [Seleccionar] </a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>