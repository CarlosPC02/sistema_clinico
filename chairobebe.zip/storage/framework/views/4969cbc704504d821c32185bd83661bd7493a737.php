<?php $__env->startSection('content'); ?>

<!-- Titulo de Menu -->
<div class="container-fluid titulo_general">
   <h6 id="titulo_principal">Completar datos MEDICO para: <strong><?php echo e(session('nombre_persona')); ?></strong></h6>
</div>

<div class="container-fluid marco_trabajo">
	
	<?php echo Form::open(['route'=>'medico.store','method'=>'POST']); ?>


		<div class="form-group">
			<?php echo Form::hidden('id_persona',$id_persona,['id'=>'id_persona','class'=>'form-control','placeholder'=>'Id_persona']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::hidden('codigo_institucion',$institucion,['id'=>'codigo_institucion','class'=>'form-control','placeholder'=>'Institucion']); ?>

		</div>

		<?php /* <div class="form-group">
			<?php echo Form::label('Especialidadcita'); ?>

			<?php echo Form::select('codigo_especialidad',$especialidad,null,['id'=>'codigo_especialidad','class'=>'form-control']); ?>

		</div> */ ?>

		<label class="form-group">Especialidad</label>
	    <div class="form-group">
            <select data-toggle="select" class="form-control select select-primary select-sm" id="codigo_especialidad" name="codigo_especialidad">
            	<option value="0">Elija Especialidad</option>
            	<?php foreach($especialidades as $especialidad): ?>
                    <option value="<?php echo e($especialidad->codigo_dominio); ?>"><?php echo e($especialidad->descripcion); ?></option>
                 <?php endforeach; ?>
            </select>
	    </div>

		<div class="form-group">
			<div class="input-group input-group-sm">
				<span class="input-group-addon">Matricula MS</span>
				<?php echo Form::text('matricula_min_salud',null,['id'=>'matricula_min_salud','class'=>'form-control','placeholder'=>'Matricula MS']); ?>

			</div>
		</div>				

		<div class="form-group">
			<div class="input-group input-group-sm">
				<span class="input-group-addon">Matricula CM</span>
				<?php echo Form::text('matricula_col_medico',null,['id'=>'matricula_col_medico','class'=>'form-control','placeholder'=>'Matricula CM']); ?>

			</div>
		</div>

		<div class="form-group">
			<div class="input-group input-group-sm">
				<span class="input-group-addon">Ranking</span>
				<?php echo Form::number('ranking',null,['id'=>'ranking','class'=>'form-control','placeholder'=>'Ranking del Medico']); ?>

			</div>
		</div>

		<div class="form-group">
			<div class="input-group input-group-sm">
				<span class="input-group-addon">Alma Mater</span>
				<?php echo Form::text('alma_mater',null,['id'=>'alma_mater','class'=>'form-control','placeholder'=>'Alma Mater']); ?>

			</div>
		</div>

		<div class="form-group">
			<?php echo Form::hidden('estado','AC',['id'=>'estado','class'=>'form-control','placeholder'=>'Estado']); ?>

		</div>

		<?php echo Form::submit('Guardar',['nombre'=>'guardar','id'=>'guardar','content'=>'<span>Guardar</span>','class'=>'btn btn-primary btn-sm m-t-10']); ?>

	<?php echo Form::close(); ?>

</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>