<div class="container-fluid">
    <div class="table-responsive">
        <div class="container-fluid">
            <table class="table table-bordered table-condensed tabla_small">
                <thead>
                    <th>IDH</th>
                    <th>Tipo</th>
                    <th>Descripcion</th>                
                </thead>
                <tbody>
                    <?php foreach($nopatologicos as $nopatologico): ?>
                    <tr>
                        <td><?php echo e($nopatologico->id_historia); ?></td>
                        <td><?php echo e($nopatologico->tipo_habito); ?></td>
                        <td><?php echo e($nopatologico->descripcionh); ?></td>
                        <!-- <td><a href="#" onclick="eliminar('{ $nopatologico->id_no_patologico}}','nopatologicosH','ListaHabitos')"> [Eliminar]</a></td> -->
                        <td><a href="#" onclick="eliminarNP('<?php echo e($nopatologico->id_no_patologico); ?>')"> [Eliminar]</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>