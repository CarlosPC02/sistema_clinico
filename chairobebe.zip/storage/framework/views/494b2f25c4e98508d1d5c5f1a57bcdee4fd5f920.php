<?php $__env->startSection('content'); ?>

<div class="container" style="padding-top: 70px;">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4>Crear Cita Para :</h4>	
			<?php /* <h5><small><?php echo e(session('id_persona')); ?></small></h5> */ ?>
			<?php echo $__env->make('Persona.LstDatosBasicos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php /* <h5><small><?php echo e(session('documento_identidad')); ?></small></h5>
			<h5><small><?php echo e(session('codigo_transaccion')); ?></small></h5> */ ?>		
		</div>		
	</div>

	<div class="panel-body">
		<?php echo Form::open(['route'=>'cita.store','method'=>'POST']); ?>


			<div class="form-group">
				<?php echo Form::hidden('id_persona',session('id_persona'),['id'=>'id_persona','class'=>'form-control','placeholder'=>'Id_persona']); ?>

			</div>

			<label class="form-group">Medico</label>
	        <div class="selectContainer">
	            <select class="form-control" id="id_medico" name="id_medico">
	            	<?php foreach($medicos as $medico): ?>
                        <option value="<?php echo e($medico->id_medico); ?>"><?php echo e($medico->nombre." ". $medico->ap_paterno." ".$medico->ap_materno); ?></option>
                     <?php endforeach; ?>
	            </select>
	        </div>

			<div class="form-group">
				<?php echo Form::label('Consultorio'); ?>

				<?php echo Form::text('id_consultorio',null,['id'=>'id_consultorio','class'=>'form-control','placeholder'=>'Consultorio']); ?>

			</div>

			<div class="form-group">
				<?php echo Form::hidden('codigo_institucion',$codigo,['id'=>'codigo_institucion','class'=>'form-control','placeholder'=>'Id_persona']); ?>

			</div>				

			<div class="form-group">
				<?php echo Form::label('Motivo'); ?>

				<?php echo Form::text('motivo',null,['id'=>'motivo','class'=>'form-control','placeholder'=>'Motivo']); ?>

			</div>

			<div class="form-group">
				<?php echo Form::label('Historia'); ?>

				<?php echo Form::text('historia',null,['id'=>'historia','class'=>'form-control','placeholder'=>'Motivo']); ?>

			</div>

			<div class="form-group">
                <label for="fecha" class="control-label">Fecha</label>
                <div class="input-group date form_date" data-date="" data-date-format="dd MM yyyy" data-link-field="fecha" data-link-format="yyyy-mm-dd">
                    <input class="form-control" size="16" type="text" value="" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
					<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                </div>
				<input type="hidden" name="fecha" id="fecha" value="" /><br/>
            </div>

			<div class="form-group">
                <label for="hora" class="control-label">Hora</label>
                <div class="input-group date form_time" data-date="" data-date-format="hh:ii" data-link-field="hora" data-link-format="hh:ii">
                    <input class="form-control" size="16" type="text" value="" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
					<span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                </div>
				<input type="hidden" name="hora" id="hora" value="" /><br/>
            </div>

			<div class="form-group">
				<?php echo Form::hidden('estado','TCEP',['id'=>'estado','class'=>'form-control','placeholder'=>'Id_persona']); ?>

			</div>

			
			<?php echo Form::submit('Guardar',['nombre'=>'guardar','id'=>'guardar','content'=>'<span>Guardar</span>','class'=>'btn btn-warning btn-sm m-t-10']); ?>


		<?php echo Form::close(); ?>

	</div>
</div>

	

	
	

	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>