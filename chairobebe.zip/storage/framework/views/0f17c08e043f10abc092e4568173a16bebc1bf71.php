<?php $__env->startSection('content'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>

<div class="container" style="padding-top: 70px;">
	<div class="container-fluid titulo general">
		<h6 id="titulo_principal">Editar Datos de Persona</h6>
	</div>

	<div class="panel-default">
		<div class="panel-heading">
			<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Por favor corrige los siguentes errores:</strong>
					<ul>
						<?php foreach($errors->all() as $error): ?>
						<li><?php echo e($error); ?></li>
						<?php endforeach; ?>
					</ul>
	    		</div>    
	 	<?php endif; ?>
		</div>

		<div class="panel-body">
			<div role="tabpanel">

				<div class="navbar-header navbar-inverse">
				    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
				        <span class="sr-only">Toggle navigation</span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				    </button>
				</div>

				<div class="collapse navbar-collapse" id="menu" role="navigation">
					<ul class="nav nav-tabs" role="tablist">
						<li class="active" role="presentation"><a href="#tab1" aria-controls="" data-toggle="tab" role="tab">Informacion basica</a></li>
						<li role="presentation"><a href="#tab2" aria-controls="" data-toggle="tab" role="tab">Informacion de contacto</a></li>
					</ul>
				</div>

				<?php echo Form::model($persona,['route'=>['persona.update',$persona->id_persona],'method'=>'put']); ?>


				<div class="tab-content">
					<div class="tab-pane active" role="tabpanel" id="tab1">
						<div class="container">
						<div class="form-group">
							<?php echo Form::label('Nombre:'); ?>

							<?php echo Form::text('nombre',null,['id'=>'nombre','class'=>'form-control','placeholder'=>'Nombre','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>
						<div class="form-group">
							<?php echo Form::label('A. Paterno:'); ?>

							<?php echo Form::text('ap_paterno',null,['id'=>'ap_paterno','class'=>'form-control','placeholder'=>'Apellido Paterno','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>
						<div class="form-group">
							<?php echo Form::label('A. Materno:'); ?>

							<?php echo Form::text('ap_materno',null,['id'=>'ap_materno','class'=>'form-control','placeholder'=>'Apellido Materno','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('Fecha de Nacimiento:'); ?>

							<?php echo Form::date('fecha_nacimiento',null,['id'=>'fecha_nacimiento','class'=>'form-control','placeholder'=>'aaaa-mm-dd','autocomplete'=>'off']); ?>

						</div>

						

						<div class="form-group">
							<label class="control-label">Tipo Documento</label>
							<div class="selectContainer">
							   <select name="tipo_documento" id="tipo_documento" class="form-control">
										<?php foreach($dominios as $dominio): ?>
												<option value="<?php echo e($dominio->codigo_dominio); ?>"><?php echo e($dominio->descripcion); ?></option>
										<?php endforeach; ?>  
									</select>
							</div>
				   		</div>

						<div class="form-group">
							<?php echo Form::label('Documento de Identidad :'); ?>

							<?php echo Form::text('documento_identidad',null,['id'=>'documento_identidad','class'=>'form-control','placeholder'=>'Documento de Identidad','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('Genero:'); ?>

							<?php echo Form::radio('genero','M',['id'=>'genero']); ?> <br>
							<?php echo Form::radio('genero','F',['id'=>'genero']); ?>

						</div>

						<?php echo Form::submit('Guardar',['nombre'=>'guardar','id'=>'guardar','content'=>'<span>Guardar</span>','class'=>'btn btn-warning']); ?>


						</div>
					</div>
					
					<!-- Tab 2 -->
					<div class="tab-pane" role="tabpanel" id="tab2">
						<div class="container">
						<div class="form-group">
							<?php echo Form::label('Celular :'); ?>

							<?php echo Form::number('no_celular',null,['id'=>'no_celular','class'=>'form-control','placeholder'=>'Telefono Celular','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('Telefono de Domicilio:'); ?>

							<?php echo Form::number('no_telefono',null,['id'=>'no_telefono','class'=>'form-control','placeholder'=>'Telefono de Domicilio','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('Telefono del Trabajo:'); ?>

							<?php echo Form::number('no_telefono_trabajo',null,['id'=>'no_telefono_trabajo','class'=>'form-control','placeholder'=>'Telefono del Trabajo','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('e-Mail :'); ?>

							<?php echo Form::email('email',null,['id'=>'email','class'=>'form-control','placeholder'=>'e-Mail','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('Direccion Actual :'); ?>

							<?php echo Form::text('direccion',null,['id'=>'direccion','class'=>'form-control','placeholder'=>'Direccion Actual','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('Ciudad de Residencia:'); ?>

							<?php echo Form::text('ciudad_residencia',null,['id'=>'ciudad_residencia','class'=>'form-control','placeholder'=>'Ciudad de Residencia','autocomplete'=>'off','style'=>'text-transform:uppercase;','onkeyup'=>'javascript:this.value=this.value.toUpperCase();']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::hidden('estado','AC',['id'=>'estado','class'=>'form-control','placeholder'=>'Estado']); ?>

						</div>
						</div>
					</div>

				</div>

				<?php echo Form::close(); ?>



			</div>
		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>