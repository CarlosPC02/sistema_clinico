<div class="container-fluid">
    <div class="table-responsive">
        <div class="container-fluid">
            <table class="table table-bordered table-condensed tabla_small">
                <thead>
                    <th>ID</th>
                    <th>Tipo Laboratorio</th>
                    <th>Orden</th>
                    <th>Fecha Programada</th>
                    <th>Urgente</th>
                </thead>
                <tbody>
                    <?php foreach($ordenes as $orden): ?>
                    <tr>
                        <td><?php echo e($orden->id_consulta); ?></td>
                        <td><?php echo e($orden->tipo_laboratorio); ?></td>
                        <td><?php echo e($orden->orden); ?></td>
                        <td><?php echo e($orden->fecha); ?></td>
                        <td><?php echo e($orden->urgente); ?></td>
                        <!-- <td><a href="#" onclick="eliminarD('{ $diagnostico->id_diagnostico}}','diagnosticosH','ListaDiagnosticos')"> [Eliminar]</a></td> -->
                        <td><a href="#" onclick="eliminarOL('<?php echo e($orden->id_orden_laboratorio); ?>')"> [Eliminar]</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>