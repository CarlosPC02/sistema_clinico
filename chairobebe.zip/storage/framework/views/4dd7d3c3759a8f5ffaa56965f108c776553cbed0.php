<div class="container">
    <div class="table-responsive">
        <div class="container-fluid">
            <table class="table table-bordered table-condensed">
                <thead>
                    <th>IDH</th>
                    <th>Tratamiento</th>
                    <th>Causal</th>
                    <th>Modo</th>                
                </thead>
                <tbody>
                    <?php foreach($tratamientos as $tratamiento): ?>
                    <tr>
                        <td><?php echo e($tratamiento->id_historia); ?></td>
                        <td><?php echo e($tratamiento->tratamiento); ?></td>
                        <td><?php echo e($tratamiento->causa_tratamiento); ?></td>
                        <td><?php echo e($tratamiento->modo_tratamiento); ?></td>
                        <td><a href="#" onclick="eliminarT('<?php echo e($tratamiento->id_tratamiento_historia); ?>')"> [Eliminar]</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>