<?php $__env->startSection('content'); ?>

<!-- Titulo de Menu -->
<div class="container-fluid titulo_general">
   <h6 id="titulo_principal">Creacion de nueva institucion</h6>
</div>

<div class="container-fluid marco_trabajo">
	<?php echo Form::open(['route'=>'institucion.store','method'=>'POST']); ?>


	<div class="form-group">
		<div class="input-group input-group-sm" style="margin-top: 10px; margin-bottom: -10px;">
			<span class="input-group-addon">Codigo</span>
			<?php echo Form::text('codigo_institucion',null,['id'=>'codigo_institucion','class'=>'form-control','placeholder'=>'Codigo']); ?>

		</div>
	</div>

	<div class="form-group">
		<div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
			<span class="input-group-addon">Tipo</span>
			<?php echo Form::text('tipo_institucion',null,['id'=>'tipo_institucion','class'=>'form-control','placeholder'=>'Tipo']); ?>

		</div>
	</div>				

	<div class="form-group">
		<div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
			<span class="input-group-addon">Nombre</span>
			<?php echo Form::text('nombre',null,['id'=>'nombre','class'=>'form-control','placeholder'=>'Nombre']); ?>

		</div>
	</div>

	<div class="form-group">
		<div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
			<span class="input-group-addon">Descripcion</span>
			<?php echo Form::text('descripcion',null,['id'=>'descripcion','class'=>'form-control','placeholder'=>'Descripcion']); ?>

		</div>
	</div>

	<div class="form-group">
		<div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
			<span class="input-group-addon">Direccion</span>
			<?php echo Form::text('direccion',null,['id'=>'direccion','class'=>'form-control','placeholder'=>'Direccion']); ?>

		</div>
	</div>

	<div class="form-group">
		<?php echo Form::hidden('estado','AC',['id'=>'estado','class'=>'form-control','placeholder'=>'Estado']); ?>

	</div>

	<?php echo Form::submit('Guardar',['nombre'=>'guardar','id'=>'guardar','content'=>'<span>Guardar</span>','class'=>'btn btn-primary boton_inferior btn-sm m-t-10']); ?>

	<?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>