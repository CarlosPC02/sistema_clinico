<?php $__env->startSection('content'); ?>

	<div class="container" style="padding-top: 70px;">
		<div class="panel panel-default">
		<div class="panel-heading">
			<h4>Lista de Medicos de la Institucion</h4>
			<p class="navbar-text navbar-right" style="margin-top: -35px;"><button class="btn btn-info navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" onclick="document.location.href='<?php echo e(route('medico.create')); ?>'">Registrar Nuevo</button></p>
			
			<?php /* <?php echo Form::open(['route'=>'persona\search','method'=>'post','class'=>'form-inline']); ?>

				<div class="form-group">
					<label for="buscar">Buscar</label>
					<input type="text" class="form-control" name="nombre">
					<button type="submit" class="btn btn-info">Buscar</button>
				</div>
			<?php echo Form::close(); ?> */ ?>

		</div>
		<div class="panel-body">
			<table class="table table-bordered table-condensed">
				<thead>
					<th>Nombre</th>
					<th>Paterno</th>
					<th>Materno</th>
					<th>Especialidad</th>
					<th>Matricula MS</th>
					<th>Matricula CM</th>
				</thead>
				<tbody>
					<?php foreach($medicos as $medico): ?>
					<tr>
						<td><?php echo e($medico-> nombre); ?></td>
						<td><?php echo e($medico-> ap_paterno); ?></td>
						<td><?php echo e($medico-> ap_materno); ?></td>
						<td><?php echo e($medico-> codigo_especialidad); ?></td>
						<td><?php echo e($medico-> matricula_min_salud); ?></td>
						<td><?php echo e($medico-> matricula_col_medico); ?></td>
						<!--<td><a href=""> [Editar] </a></td>
						<td><a href=""> [Trabajar] </a></td>-->
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>