<div class="container">
    <div class="table-responsive">
        <div class="container-fluid">
            <table class="table table-bordered table-condensed">
                <thead>
                    <th>IDH</th>
                    <th>Diagnostico</th>
                    <th>CIE 10</th>
                    <th>Tipo</th>
                    <th>Comentarios</th>                
                </thead>
                <tbody>
                    <?php foreach($diagnosticos as $diagnostico): ?>
                    <tr>
                        <td><?php echo e($diagnostico->id_historia); ?></td>
                        <td><?php echo e($diagnostico->diagnostico); ?></td>
                        <td><?php echo e($diagnostico->diagnostico_cie10); ?></td>
                        <td><?php echo e($diagnostico->agudo_cronico); ?></td>
                        <td><?php echo e($diagnostico->comentarios); ?></td>
                        <td><a href="#" onclick="eliminarD('<?php echo e($diagnostico->id_diagnostico_historia); ?>')"> [Eliminar]</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>