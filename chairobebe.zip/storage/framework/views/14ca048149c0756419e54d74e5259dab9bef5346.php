<div class="container-fluid paciente_encontrado">
      
      <div class="thumb_paciente"><img src="" class="img-responsive" alt="S/I"></div>
      <h5> <?php echo e(session('nombre_persona')); ?>  | <small>Fecha de Nac: <?php echo e(session('fecha_nacimiento')); ?></small></h5>
      <p> Paciente ID: <?php echo e(session('id_paciente')); ?></p>
      
      <p class="navbar-text navbar-right" style="margin-top: -35px;">
      <button class="btn btn-info navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" onclick="document.location.href='<?php echo e(route('persona.edit',session('id_persona'))); ?>'">Detalles</button>
      </p>
      <p>
      <button class="btn btn-success navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" >Editar Imagen</button>
      </p>

</div>