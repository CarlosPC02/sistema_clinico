<?php $__env->startSection('content'); ?>
<!-- Titulo de Menu -->
<div class="container-fluid titulo_general">
  <h6 id="titulo_principal">Consulta ya existe para la fecha: <?php echo e($fecha); ?></h6>
</div>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h5>Desea...</h5>
		</div>
		<div class="panel-body">
			<a href="<?php echo e(route('consulta.create')); ?>" class="btn btn-success">Crear una Nueva Consulta</a>
			<a href="<?php echo e(route('consulta.edit',$idc)); ?>" class="btn btn-warning">Editar la Consulta</a>
		</div>
	</div>
</div>

<!-- Fin de Titulo -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>