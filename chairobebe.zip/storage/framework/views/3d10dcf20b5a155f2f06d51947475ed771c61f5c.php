<div class="panel-heading">
    <center><b>CITAS PARA : <?php echo e($fecha); ?></b></center>
</div>
<!-- Formulario de Listado de Persona -->
<?php echo e(csrf_field()); ?>

<div class="table-responsive">
        <table class="table table-bordered table-condensed tabla_small">
            <thead>
                    <th>Institucion</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Nombre</th>
                    <th>Paterno</th>
                    <th>Motivo</th>
                    <th>Medico</th>
                    <th>Opciones</th>
                </thead>
            <tbody>
                    <?php foreach($citas as $cita): ?>
                    <tr>
                        <td><?php echo e($cita-> codigo_institucion); ?></td>
                        <td><?php echo e($cita-> fecha); ?></td>
                        <td><?php echo e($cita-> hora); ?></td>
                        <td><?php echo e($cita-> nombre); ?></td>
                        <td><?php echo e($cita-> ap_paterno); ?></td>
                        <td><?php echo e($cita-> motivo); ?></td>
                        <td> <?php echo e($cita->nombrem); ?> <?php echo e($cita->apellidom); ?></td>
                        <td><a href="#" data-toggle="tooltip" title="Editar"><span class="glyphicon glyphicon-edit" style="color: #1ABC9C; text-align: center;"></span></a>
                            <a href="#" data-toggle="tooltip" title="Eliminar"><span class="glyphicon glyphicon-remove-circle" style="color: #C0392B; text-align: center;"></span></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
        </table>
</div>