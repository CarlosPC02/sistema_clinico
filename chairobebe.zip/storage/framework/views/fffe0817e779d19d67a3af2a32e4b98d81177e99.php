<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 70px;">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h4>Usuarios</h4>
			<p class="navbar-text navbar-right" style="margin-top: -35px;"><button class="btn btn-info navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" onclick="document.location.href='<?php echo e(route('usuario.create')); ?>'">Registrar Nuevo</button></p>
			
		</div>
		<div class="panel-body">
			<table class="table table-bordered table-condensed">
				<thead>
					<?php /* <th>#</th> */ ?>
					<th>username</th>
					<th>password</th>
					<th>email</th>
					<th>institucion</th>
					<?php /* <th>Direccion</th>
					<th>Estado</th> */ ?>
				</thead>
				<tbody>
					<?php foreach($usuarios as $usuario): ?>
					<tr>
						<?php /* <td><?php echo e($persona-> id_persona); ?></td> */ ?>
						<td><?php echo e($usuario-> name); ?></td>
						<td><?php echo e($usuario-> password); ?></td>
						<td><?php echo e($usuario-> email); ?></td>
						<td><?php echo e($usuario-> codigo_institucion); ?></td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>