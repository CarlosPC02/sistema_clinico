<?php $__env->startSection('title','MENU DE TRABAJO'); ?>
<?php $__env->startSection('content'); ?>

<!-- Titulo de Menu -->
<div class="container-fluid titulo_general">
   <h6 id="titulo_principal">Menu de Trabajo</h6>
</div>

<div class="container-fluid marco_trabajo">

    <div><?php echo $__env->make('Persona.LstDatosBasicos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
    <?php if($resultado === 0): ?>
        <div class="alert alert-warning">
    
            <h6>ATENCION!</h6>
            <p>Hay datos importantes que aun no se han detallado</p>
            <p class="navbar-text navbar-right" style="margin-top: -35px;"><button class="btn btn-warning navbar-btn" type="button" style="margin-top: 1px; margin-bottom: 1px; margin-right: 8px; padding: 5px 5px;" onclick="document.location.href='<?php echo e(route('paciente.edit',session('id_persona'))); ?>'">Completar Ahora</button></p>
        </div>
    <?php else: ?>
        <div class="alert alert-success">
            <p>OK! Todos los datos estan llenos</p>
        </div>
    <?php endif; ?>
    <div class="container">
            <div class="row cuadro_principal_menu">
                <div class="cuadro_menu"> <a href="laboratorio.html">
                    <div class="imagen_menu">
                        <img class="img-responsive" src="<?php echo e(asset('../imagenes/menu/laboratorio_w.png')); ?>" alt="Laboratorios">
                    </div>
                    <div class="titulo_menu">
                        Laboratorios
                    </div>
                    <div class="texto_menu">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis architecto omnis natus culpa labore pariatur aut quos facere possimus iste.</p>
                    </div>
                    <br>
                    </a>
                </div>
                
                <div class="cuadro_menu"> <a href="gabinete.html">
                    <div class="imagen_menu">
                        <img class="img-responsive" src="<?php echo e(asset('../imagenes/menu/gabinete_w.png')); ?>" alt="Gabinete">
                    </div>
                    <div class="titulo_menu">
                        Gabinete
                    </div>
                    <div class="texto_menu">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis architecto omnis natus culpa labore pariatur aut quos facere possimus iste.</p>
                    </div>
                    <br>
                    </a>
                </div>
                
                <div class="cuadro_menu"><a href="quirofano.html">
                    <div class="imagen_menu">
                        <img class="img-responsive" src="<?php echo e(asset('../imagenes/menu/quirofano_w.png')); ?>" alt="Quirofano">
                    </div>
                    <div class="titulo_menu">
                        Quirofano
                    </div>
                    <div class="texto_menu">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis architecto omnis natus culpa labore pariatur aut quos facere possimus iste.</p>
                    </div>
                    <br></a>
                </div>
                
                <div class="cuadro_menu"><a href="<?php echo e(route('historia.show',session('id_paciente'))); ?>">
                    <div class="imagen_menu">
                        <img class="img-responsive" src="<?php echo e(asset('../imagenes/menu/expediente_w.png')); ?>" alt="Expediente">
                    </div>
                    <div class="titulo_menu">
                        Expediente
                    </div>
                    <div class="texto_menu">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis architecto omnis natus culpa labore pariatur aut quos facere possimus iste.</p>
                    </div>
                    <br></a>
                </div>
                
                <div class="cuadro_menu"><a href="estadistica.html">
                    <div class="imagen_menu">
                        <img class="img-responsive" src="<?php echo e(asset('../imagenes/menu/estadisticas_w.png')); ?>" alt="Estadisticas">
                    </div>
                    <div class="titulo_menu">
                        Estadisticas
                    </div>
                    <div class="texto_menu">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis architecto omnis natus culpa labore pariatur aut quos facere possimus iste.</p>
                    </div>
                    <br></a>
                </div>
                
            </div>
    </div>
</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>