<?php $__env->startSection('content'); ?>

	<div class="container" style="padding-top: 70px;">
		<div class="panel panel-default">
		<div class="panel-heading">
			<h4>Completar Datos de MEDICO para:</h4>	
			<?php /* <h5><small><?php echo e(session('id_persona')); ?></small></h5> */ ?>
			<h2><?php echo e(session('nombre_persona')); ?></h2>
		</div>
		<div class="panel-body">
			<?php echo Form::open(['route'=>'medico.store','method'=>'POST']); ?>


				<div class="form-group">
					<?php echo Form::hidden('id_persona',$id_persona,['id'=>'id_persona','class'=>'form-control','placeholder'=>'Id_persona']); ?>

				</div>

				<div class="form-group">
					<?php echo Form::hidden('codigo_institucion',$institucion,['id'=>'codigo_institucion','class'=>'form-control','placeholder'=>'Institucion']); ?>

				</div>

				<?php /* <div class="form-group">
					<?php echo Form::label('Especialidad'); ?>

					<?php echo Form::select('codigo_especialidad',$especialidad,null,['id'=>'codigo_especialidad','class'=>'form-control']); ?>

				</div> */ ?>

				<label class="form-group">Especialidad</label>
			        <div class="selectContainer">
			            <select class="form-control" id="codigo_especialidad" name="codigo_especialidad">
			            	<option value="">Elija Especialidad</option>
			            	<?php foreach($especialidades as $especialidad): ?>
		                        <option value="<?php echo e($especialidad->codigo_dominio); ?>"><?php echo e($especialidad->descripcion); ?></option>
		                     <?php endforeach; ?>
			            </select>
			        </div>

				<div class="form-group">
					<?php echo Form::label('Matricula MS'); ?>

					<?php echo Form::text('matricula_min_salud',null,['id'=>'matricula_min_salud','class'=>'form-control','placeholder'=>'Matricula MS']); ?>

				</div>				

				<div class="form-group">
					<?php echo Form::label('Matricula CM'); ?>

					<?php echo Form::text('matricula_col_medico',null,['id'=>'matricula_col_medico','class'=>'form-control','placeholder'=>'Matricula CM']); ?>

				</div>

				<div class="form-group">
					<?php echo Form::label('Ranking del Medico'); ?>

					<?php echo Form::number('ranking',null,['id'=>'ranking','class'=>'form-control','placeholder'=>'Ranking del Medico']); ?>

				</div>

				<div class="form-group">
					<?php echo Form::label('Alma Mater'); ?>

					<?php echo Form::text('alma_mater',null,['id'=>'alma_mater','class'=>'form-control','placeholder'=>'Alma Mater']); ?>

				</div>

				<div class="form-group">
					<?php echo Form::hidden('estado','AC',['id'=>'estado','class'=>'form-control','placeholder'=>'Estado']); ?>

				</div>

				<?php echo Form::submit('Guardar',['nombre'=>'guardar','id'=>'guardar','content'=>'<span>Guardar</span>','class'=>'btn btn-warning btn-sm m-t-10']); ?>

			<?php echo Form::close(); ?>

		</div>
	</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>