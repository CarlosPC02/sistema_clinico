<div class="alert alert-success">
	
	<h6>OK!</h6>
	<p>Todos los datos estan llenos</p>
	
</div>