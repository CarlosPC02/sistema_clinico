<?php $__env->startSection('title','Signos Vitales'); ?>

<?php $__env->startSection('content'); ?>

<!-- Titulo de Menu -->
<div class="container-fluid titulo_general">
  <h6 id="titulo_principal">Signos Vitales</h6>
</div>
<!-- Fin de Titulo -->

<div class="container-fluid marco_trabajo">

	<div><?php echo $__env->make('Persona.LstDatosBasicos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>

	<!-- Signos Vitales -->
	<!-- Tabpanels de signos vitales -->
	<div class="container-fluid paciente_encontrado">
	<div role="tabpanel">
		<!--crea boton de menu al estrecharse la resolucion de pantalla-->
		<div class="navbar-header navbar-default">
		    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		    </button>
		</div>
		
		<!--incluye el menu en la referencia del boton creado antes-->
		<div class="collapse navbar-collapse marco_tabs" id="menu" role="navigation">
			<ul class="nav nav-tabs" role="tablist">
				<li class="active" role="presentation"><a href="#tab1" aria-controls="" data-toggle="tab" role="tab">Signos Vitales</a></li>
				<li role="presentation"><a href="#tab2" aria-controls="" data-toggle="tab" role="tab">Grafica</a></li>
			</ul>
		</div>

		<div class="tab-content">

		<div role="tabpanel" class="tab-pane active" id="tab1">
			<div class="container-fluid marco_trabajo_paciente">
<!-- 
			<h5>Fecha Actual: <?php echo e($fecha_actual); ?></h5>
 -->			<div class="table-responsive">
				<table class="table table-bordered table-condensed tabla_small">
					<thead>
						<th>Fecha</th>
						<th>Peso</th>
						<th>Talla</th>
						<th>IMC</th>
						<th>P.Sist.</th>
						<th>P.Diast.</th>
						<th>F.Card</th>
						<th>F.Resp</th>
						<th>Temp °C</th>
						<th>SPO2</th>
						<th>Dolor</th>
						<th>Obs</th>
					</thead>
					<tbody>
						<?php foreach($mediciones as $medicion): ?>
						<tr>
							<td><?php echo e($medicion-> fecha); ?></td>
							<td><?php echo e($medicion-> peso); ?></td>
							<td><?php echo e($medicion-> estatura); ?></td>
							<td><?php echo e($medicion-> imc); ?></td>
							<td><?php echo e($medicion-> presion_sistolica); ?></td>
							<td><?php echo e($medicion-> presion_diastolica); ?></td>
							<td><?php echo e($medicion-> frecuencia_cardiaca); ?></td>
							<td><?php echo e($medicion-> frecuencia_respiratoria); ?></td>
							<td><?php echo e($medicion-> temperatura); ?></td>
							<td><?php echo e($medicion-> spo2); ?></td>
							<td><?php echo e($medicion-> dolor); ?></td>
							<td><?php echo e($medicion-> observaciones); ?></td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				</div>

				<!-- Boton de Registro de nuevos signos vitales -->
				<a href="#signos" data-toggle="modal" class="btn btn-primary">Registrar Signos Vitales</a>

			</div>
		</div>

		<!--seccion de signos historicos-->
		<div class="tab-pane" id="tab2" role="tabpanel">
			<div class="container-fluid marco_trabajo_paciente">
				<h5>Grafica de trabajo</h5>
				<div id="curve_chart" style="width: 1024px; height: 500px"></div>
			</div>
		</div>

		</div>
		</div>
	</div>

		|<!--Modales-->
	<!--modal para signos vitales-->
	<div class="modal fade" id="signos" role="dialog" aria-hidden="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h5 class="modal-title">Registrar Signos Vitales</h5>
				</div>
				<div class="modal-body">
				<!--Formulario de Registro de Signos Vitales-->
				<?php echo Form::open(['route'=>'medicion.store','method'=>'POST']); ?>

				<?php echo e(csrf_field()); ?>

					
					<div class="form-group">
						<?php echo Form::hidden('id_persona',session('id_persona'),['id'=>'id_persona']); ?>

					</div>

		            <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-bottom: -10px;">
				            <span class="input-group-addon">Fecha Toma</span>
				            <input id="fecha" type="date" name="fecha" value=<?php echo e($fecha_actual); ?> class="form-control" placeholder="Fecha toma" autocomplete="off" autofocus>
				        </div>
				    </div>

				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">Peso</span>
				            <input id="peso" type="number" name="peso" class="form-control" placeholder="Peso Paciente" autocomplete="off" autofocus>
				        </div>
				    </div>

				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">Talla</span>
				            <input id="estatura" type="number" name="estatura" class="form-control" placeholder="Talla Paciente" autocomplete="off" autofocus>
				        </div>
				    </div>
				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">IMC</span>
				            <input id="imc" type="number" name="imc" class="form-control" placeholder="Indice Masa Corporal" autocomplete="off" autofocus>
				        </div>
				    </div>
				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">P. Sistolica</span>
				            <input id="presion_sistolica" type="number" name="presion_sistolica" class="form-control" placeholder="Presion Sistólica" autocomplete="off" autofocus>
				        </div>
				    </div>
				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">P. Diastolica</span>
				            <input id="presion_diastolica" type="number" name="presion_diastolica" class="form-control" placeholder="Presion Diastólica" autocomplete="off" autofocus>
				        </div>
				    </div>
				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">F. Cardiaca</span>
				            <input id="frecuencia_cardiaca" type="number" name="frecuencia_cardiaca" class="form-control" placeholder="Frecuencia Cardíaca" autocomplete="off" autofocus>
				        </div>
				    </div>
				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">F. Respiratoria</span>
				            <input id="frecuencia_respiratoria" type="number" name="frecuencia_respiratoria" class="form-control" placeholder="Frecuencia Respiratoria" autocomplete="off" autofocus>
				        </div>
				    </div>
				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">Temp. (°C)</span>
				            <input id="temperatura" type="number" name="temperatura" class="form-control" placeholder="Temperatura Corporal" autocomplete="off" autofocus>
				        </div>
				    </div>
				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">SPO2(%)</span>
				            <input id="spo2" type="number" name="spo2" class="form-control" placeholder="SPO2" autocomplete="off" autofocus>
				        </div>
				    </div>
				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">Dolor(1-10)</span>
				            <input id="dolor" type="number" name="dolor" class="form-control" placeholder="Nivel Dolor" autocomplete="off" autofocus>
				        </div>
				    </div>

				    <div class="form-group">
				        <div class="input-group input-group-sm" style="margin-top: -10px; margin-bottom: -10px;">
				            <span class="input-group-addon">Observaciones</span>
				            <input id="observaciones" type="text" name="observaciones" class="form-control" placeholder="Observaciones" autocomplete="off" autofocus>
				        </div>
				    </div>

				    <div class="form-group">
						<div class="input-group input-group-sm">
				            <input id="estado" type="hidden" name="estado" class="form-control" value="AC">
				        </div>
					</div>
					<!-- </form> -->
					<?php echo Form::submit('Guardar',['nombre'=>'guardar','id'=>'guardar','content'=>'<span>Guardar</span>','class'=>'btn btn-primary btn-sm']); ?>


					<?php echo Form::close(); ?>

					<!-- Fin de formulario de registro de signos vitales -->
				</div>
			</div>
		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>