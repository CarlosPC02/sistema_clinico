<div class="container">
    <div class="table-responsive">
        <div class="container-fluid">
            <table class="table table-bordered table-condensed">
                <thead>
                    <th>IDH</th>
                    <th>Tipo</th>
                    <th>Descripcion</th>                
                </thead>
                <tbody>
                    <?php foreach($antecedentes as $antecedente): ?>
                    <tr>
                        <td><?php echo e($antecedente->id_historia); ?></td>
                        <td><?php echo e($antecedente->tipo_antecedente); ?></td>
                        <td><?php echo e($antecedente->descripcion); ?></td>
                        <td><a href="#" onclick="eliminarN('<?php echo e($antecedente->id_antecedente_historia); ?>')"> [Eliminar]</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>