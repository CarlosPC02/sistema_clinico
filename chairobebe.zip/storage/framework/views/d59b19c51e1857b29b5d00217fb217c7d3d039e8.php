<div class="container-fluid">
    <div class="table-responsive">
        <div class="container-fluid">
            <table class="table table-bordered table-condensed tabla_small">
                <thead>
                    <th>IDH</th>
                    <th>Tipo</th>
                    <th>Severidad</th>
                    <th>Agente</th>                
                </thead>
                <tbody>
                    <?php foreach($alergias as $alergia): ?>
                    <tr>
                        <td><?php echo e($alergia->id_historia); ?></td>
                        <td><?php echo e($alergia->tipo_alergia); ?></td>
                        <td><?php echo e($alergia->severidad); ?></td>
                        <td><?php echo e($alergia->agente); ?></td>
                        <!-- <td><a href="#" onclick="eliminar('{ $alergia->id_alergia}}','alergia','ListaAlergias')"> [Eliminar]</a></td> -->
                        <td><a href="#" onclick="eliminarA('<?php echo e($alergia->id_alergia); ?>')"> [Eliminar]</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
