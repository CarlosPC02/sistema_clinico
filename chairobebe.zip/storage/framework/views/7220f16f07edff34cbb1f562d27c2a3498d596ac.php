<div class="container-fluid">
    <div class="table-responsive">
        <div class="container-fluid">
            <table class="table table-bordered table-condensed tabla_small">
                <thead>
                    <th>IDE</th>
                    <th>Tipo Diagnostico</th>
                    <th>Descripcion</th>
                    <th>CIE</th>
                </thead>
                <tbody>
                    <?php foreach($diagnosticos as $diagnostico): ?>
                    <tr>
                        <td><?php echo e($diagnostico->id_evaluacion); ?></td>
                        <td><?php echo e($diagnostico->tipo_diagnostico); ?></td>
                        <td><?php echo e($diagnostico->descripcion); ?></td>
                        <td><?php echo e($diagnostico->codigo_cie); ?></td>
                        <!-- <td><a href="#" onclick="eliminarD('{ $diagnostico->id_diagnostico}}','diagnosticosH','ListaDiagnosticos')"> [Eliminar]</a></td> -->
                        <td><a href="#" onclick="eliminarD('<?php echo e($diagnostico->id_diagnostico); ?>')"> [Eliminar]</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>