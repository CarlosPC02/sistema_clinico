<!DOCTYPE html>
<!--PAGINA NUMERO UNO DE PARACELSO-->
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Plataforma de asistencia para médicos y especialistas que apoya en la atención de pacientes"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Metas para evitar boton atras e ingreso al aplicativo -->
    <meta http-equiv="cache-control" content="max-age=0" />
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="cache-control" content="no-store" />
    <meta http-equiv="cache-control" content="must-revalidate" />
    <meta http-equiv="expires" content="0" />
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
    <meta http-equiv="pragma" content="no-cache" />
    <!-- Fin de metas -->

    <title>Plataforma Paracelso</title>

    <!-- Fonts -->

   <!-- Styles -->
    <!-- RESET -->
    <?php echo Html::style('css/reset.css'); ?>

    <!-- Loading Bootstrap -->
    <?php echo Html::style('css/vendor/bootstrap/css/bootstrap.min.css'); ?>

    <!-- Loading Flat UI / El CSS ya carga Fonts para el estilo-->
    <?php echo Html::style('css/flat-ui.css'); ?>

    <!--Estilo Propio-->
    <?php echo Html::style('css/global.css'); ?>

    <!-- Icono superior Paracelso -->
    <link rel="shortcut icon" href="<?php echo e(asset('imagenes/favicon/favicon.ico')); ?>">
    
</head>
<body id="app-layout">
    <!-- Navegacion externa basica -->
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container-fluid">
            <div class="navbar-header">

                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                </button>

                <!-- Branding Image -->
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    TIMNet Bolivia
                </a>
            </div>

            <div class="navbar-collapse collapse" id="app-navbar-collapse">
                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    
                    <li><a href="<?php echo e(url('pstsolucion')); ?>">Soluciones</a></li>
                    <li><a href="<?php echo e(url('pstempresa')); ?>">Empresa</a></li>
                    <li><a href="<?php echo e(url('pstayuda')); ?>">Ayuda</a></li>

                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(url('/login')); ?>">Ingresar</a></li>
                        <li><a href="<?php echo e(url('/register')); ?>">Registrar</a></li>
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="<?php echo e(url('lstcalendario')); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Salir</a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <!--Fin de navegacion-->

    <!-- Definicion de Footer Paracelso -->
    <footer>
      <div class="footer" style="float:left; padding-top:15px;"> 
        <div class="container">
            <p><span class="fui-location"> </span> Edif. CES, Of. #204, Obraje calle 6, La Paz - Bolivia</p>
            <p><span class="fui-chat"> </span> (+591) 720 00301 / (+591) 673 13333</p>
            <p><span class="fui-mail"> </span>gerencia@timnetbo.com / soporte@timnetbo.com</p>
        </div>
       </div>
       
       <!-- Se deden definir los iconos sociales a la derecha y derechos reservados por debajo -->
   </footer>
   <!-- Final de Footer -->


    <?php echo $__env->yieldContent('content'); ?>

    <!-- JavaScripts -->
    <script src="<?php echo e(asset('js/vendor/bootstrap.min.js')); ?>"  crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/vendor/jquery.min.js')); ?>"  crossorigin="anonymous"></script>
    
    
    <script src="<?php echo e(asset('js/flat-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/application.js')); ?>"></script>
    <?php /* <script src="<?php echo e(elixir('js/app.js')); ?>"></script> */ ?>
</body>
</html>