<?php $__env->startSection('content'); ?>

	<div class="container" style="padding-top: 70px;">
		<div class="panel panel-default">
		<div class="panel-heading">
			<h4>Crear Nueva Institucion</h4>
		</div>
		<div class="panel-body">
			<?php echo Form::open(['route'=>'institucion.store','method'=>'POST']); ?>


				<div class="form-group">
					<?php echo Form::label('Codigo'); ?>

					<?php echo Form::text('codigo_institucion',null,['id'=>'codigo_institucion','class'=>'form-control','placeholder'=>'Codigo']); ?>

				</div>

				<div class="form-group">
					<?php echo Form::label('Tipo'); ?>

					<?php echo Form::text('tipo_institucion',null,['id'=>'tipo_institucion','class'=>'form-control','placeholder'=>'Tipo']); ?>

				</div>				

				<div class="form-group">
					<?php echo Form::label('Nombre'); ?>

					<?php echo Form::text('nombre',null,['id'=>'nombre','class'=>'form-control','placeholder'=>'Nombre']); ?>

				</div>

				<div class="form-group">
					<?php echo Form::label('Descripcion'); ?>

					<?php echo Form::text('descripcion',null,['id'=>'descripcion','class'=>'form-control','placeholder'=>'descripcion']); ?>

				</div>

				<div class="form-group">
					<?php echo Form::label('Direccion'); ?>

					<?php echo Form::text('direccion',null,['id'=>'direccion','class'=>'form-control','placeholder'=>'Direccion']); ?>

				</div>

				<div class="form-group">
					<?php echo Form::hidden('estado','AC',['id'=>'estado','class'=>'form-control','placeholder'=>'Estado']); ?>

				</div>

				<?php echo Form::submit('Guardar',['nombre'=>'guardar','id'=>'guardar','content'=>'<span>Guardar</span>','class'=>'btn btn-warning btn-sm m-t-10']); ?>

			<?php echo Form::close(); ?>

		</div>
	</div>
	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.paracelso', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>