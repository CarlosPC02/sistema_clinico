<div class="panel-heading">
    <center>CITAS PARA : <?php echo e($fecha); ?></center>
</div>

<!-- Formulario de Listado de Persona -->
<?php echo e(csrf_field()); ?>

<div class="table-responsive">
    <div class="container-fluid">
        <table class="table table-bordered table-condensed">
            <thead>
                    <th>Institucion</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Nombre</th>
                    <th>Paterno</th>
                    <th>Motivo</th>
                    <th>Medico</th>
                </thead>
            <tbody>
                    <?php foreach($citas as $cita): ?>
                    <tr>
                        <td><?php echo e($cita-> codigo_institucion); ?></td>
                        <td><?php echo e($cita-> fecha); ?></td>
                        <td><?php echo e($cita-> hora); ?></td>
                        <td><?php echo e($cita-> nombre); ?></td>
                        <td><?php echo e($cita-> ap_paterno); ?></td>
                        <td><?php echo e($cita-> motivo); ?></td>
                        <td> <?php echo e($cita->nombrem); ?> <?php echo e($cita->apellidom); ?></td>

                    </tr>
                    <?php endforeach; ?>
                </tbody>
        </table>
    </div>
</div>