<?php

namespace App\Http\Controllers\Historia;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Administracion\BitacoraControlador;
use App\Models\HistoriaClinica;

class HistoriaControlador extends Controller
{
    //
    
}
