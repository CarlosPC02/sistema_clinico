@extends('layouts.principal')

@section('content')

<div class="container-fluid">
    <h3>Soluciones integrales para la medicina moderna</h3>
	<br>
    <br>
    <h4>Paracelso</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam, necessitatibus dicta officiis quod qui quam in totam temporibus. Odio, ducimus, ad, harum sequi hic quo quibusdam optio enim quas nostrum totam laboriosam deleniti facilis mollitia eos ipsa molestias earum reprehenderit vero culpa illo ea iste doloribus qui et consectetur quae.</p>
    <br>
    <h4>P&#225;ginas web</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam, necessitatibus dicta officiis quod qui quam in totam temporibus. Odio, ducimus, ad, harum sequi hic quo quibusdam optio enim quas nostrum totam laboriosam deleniti facilis mollitia eos ipsa molestias earum reprehenderit vero culpa illo ea iste doloribus qui et consectetur quae.</p>
    <br>
    <h4>Manejo de redes sociales</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam, necessitatibus dicta officiis quod qui quam in totam temporibus. Odio, ducimus, ad, harum sequi hic quo quibusdam optio enim quas nostrum totam laboriosam deleniti facilis mollitia eos ipsa molestias earum reprehenderit vero culpa illo ea iste doloribus qui et consectetur quae.</p>
    <br>
    <h4>Asesoramiento y soporte t&#233;cnico</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam, necessitatibus dicta officiis quod qui quam in totam temporibus. Odio, ducimus, ad, harum sequi hic quo quibusdam optio enim quas nostrum totam laboriosam deleniti facilis mollitia eos ipsa molestias earum reprehenderit vero culpa illo ea iste doloribus qui et consectetur quae.</p>
	<br>

</div>

@endsection