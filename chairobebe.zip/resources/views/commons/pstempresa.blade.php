@extends('layouts.principal')

@section('content')

	<div class="container-fluid">
        <h3>Conozca TIMNet</h3>
        <br>
        <h4>Quienes somos</h4>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque, sit, modi veniam quo obcaecati repellendus quasi necessitatibus illo non maxime maiores nesciunt debitis libero voluptates consequatur earum soluta similique consequuntur atque nihil temporibus officia voluptatem deserunt aliquam dignissimos explicabo molestiae suscipit animi ipsa velit! Enim, quas recusandae earum blanditiis quo!</p>
        <br>
        <h4>Lo que hacemos</h4>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque, sit, modi veniam quo obcaecati repellendus quasi necessitatibus illo non maxime maiores nesciunt debitis libero voluptates consequatur earum soluta similique consequuntur atque nihil temporibus officia voluptatem deserunt aliquam dignissimos explicabo molestiae suscipit animi ipsa velit! Enim, quas recusandae earum blanditiis quo!</p>
        <br>
        <h4>El Equipo</h4>
        <li><strong>Samuel Orellana</strong></li>
        <li><strong>Damian Espinoza</strong></li>
        <li><strong>Ariel Ibarra</strong></li>
        <br>
        <h4>Donde nos encontramos</h4>
        <p>Google Maps</p>
        <br>
        
	</div>

@endsection